package Question2;

public class Connect4Model {
	
	String[] pattern={"OOOOOOOOOOOOOOOOOOOOOOOOO"," OOOOOOOOOOOOOOOOOOOOOOO ","  OOOOOOOOOOOOOOOOOOOOO  ","   OOOOOOOOOOOOOOOOOOO   ","    OOOOOOOOOOOOOOOOO    ","     OOOOOOOOOOOOOOO     ","      OOOOOOOOOOOOO      ","       OOOOOOOOOOO       ","        OOOOOOOOO        "};
	int lastMoveRow, lastMoveColumn, moveNumber=0;
	char lastMoveSymbol;
	
	public void resetPattern(){
		pattern=new String[]{"OOOOOOOOOOOOOOOOOOOOOOOOO"," OOOOOOOOOOOOOOOOOOOOOOO ","  OOOOOOOOOOOOOOOOOOOOO  ","   OOOOOOOOOOOOOOOOOOO   ","    OOOOOOOOOOOOOOOOO    ","     OOOOOOOOOOOOOOO     ","      OOOOOOOOOOOOO      ","       OOOOOOOOOOO       ","        OOOOOOOOO        "};
	}

	public String toString(){
		String displayPattern = "";
		for(int i=0;i<9;i++)
			displayPattern = displayPattern+"\n"+pattern[i];
		return displayPattern;
	}
	
	public boolean checkIfPieceCanBeDroppedIn(int column) {
		//If column number entered by user is greater than board columns or less than zero, fail dropTest
		for(int i1 = 8; i1>=0;i1--)
			if(pattern[i1].charAt(column) == 'O'){
				lastMoveRow = i1;
				lastMoveColumn = column;
				return true;
			}
		return false;			
	}
	
	public boolean verifyColumn(int column){
		if(column<0||column>24)
			return false;
		else 
			return true;
	}
	
	public void dropPieces(int i, char c){
		if(checkIfPieceCanBeDroppedIn(i))		
		{
			pattern[lastMoveRow] = pattern[lastMoveRow].substring(0, i)+c+pattern[lastMoveRow].substring(i+1, 25);
			lastMoveSymbol = c;
			moveNumber++;
		}
	}
	
	public boolean didLastMoveWin(){
		int score=0;
		
		//Verify if last player formed connectFour in row
		if(pattern[lastMoveRow].contains(""+lastMoveSymbol+lastMoveSymbol+lastMoveSymbol+lastMoveSymbol))
			return true;
		//Verify if last player formed connectFour in column
		score=0;
		for(int i = lastMoveRow - 3; (i<=(lastMoveRow+3))&&(i<9); i++){			
			if(i<0)
				continue;
			score = pattern[i].charAt(lastMoveColumn)==lastMoveSymbol?score+1:0;
			if(score==4)
				return true;
		}
		//Verify if last player formed connectFour diagonally left to right \
		score=0;
		for(int i = lastMoveRow-3, j = lastMoveColumn - 3;(i<=lastMoveRow+3)&&(j<=lastMoveColumn+3)&&(i<9)&&(j<25);i++,j++){
			if((i<0)||(j<0))
				continue;
			score = pattern[i].charAt(j)==lastMoveSymbol?score+1:0;
			if(score==4)
				return true;
		}
		//Verify if last player formed connectFour diagonally right to left /
		score=0;
		for(int i = lastMoveRow-3, j = lastMoveColumn+3;(i<=lastMoveRow+3)&&(j>=lastMoveColumn-3)&&(i<9)&&(j>0);i++,j--){
			if((i<0)||(j>24))
				continue;
			score = pattern[i].charAt(j)==lastMoveSymbol?score+1:0;			
			if(score==4)
				return true;
		}	
		return false;
	}

	public boolean isItaDraw(){
		for(int i=0;i<9;i++){
			if(pattern[i].contains("O"));
			return false;
		}
		return true;		  
	}


}
