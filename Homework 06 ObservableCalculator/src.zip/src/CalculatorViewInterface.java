
public interface CalculatorViewInterface {

	public void menu();
	public void displayOutput(Double answer);
}
