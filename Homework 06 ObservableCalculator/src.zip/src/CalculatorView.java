import java.math.BigDecimal;
import java.util.Observable;
import java.util.Observer;

public class CalculatorView implements CalculatorViewInterface {

	public void menu(){
		System.out.println("Enter Valid Expression:");
	}
	
	public void displayOutput(Double answer){
		System.out.println("\nOutput is: "+new BigDecimal(answer).toPlainString());
		System.out.println("Thank You!");
	}


}
