
public interface CalculatorControllerInterface {
	
	public void displayMenu();
	
	public void getExpression();
	
	public void setExpression();
	
	public Double getAnswer();

}
