import java.util.Observable;
import java.util.Observer;
import java.util.Scanner;

public class CalculatorController implements Observer, CalculatorControllerInterface {

	@Override
	public void update(Observable calculatorModel, Object arg) {
		calcView.displayOutput(getAnswer());
	}

	String expression ="";
	CalculatorView calcView = new CalculatorView();
	CalculatorModel calcModel = new CalculatorModel(this);
	
	@Override
	public void displayMenu(){
		calcView.menu();
	}
	
	@Override
	public void getExpression(){
		Scanner s = new Scanner(System.in);
		expression = s.nextLine();
		s.close();
	}
	
	@Override
	public void setExpression(){
		calcModel.setExpression(expression);
	}
	
	@Override
	public Double getAnswer(){
		calcModel.infixToPostfix();
		calcModel.evaluatePostfix();
		return calcModel.getAnswer();
	}
	

	public static void main(String args[]){
		CalculatorController newCalc = new CalculatorController();
		newCalc.displayMenu();
		newCalc.getExpression();
		newCalc.setExpression();
	}
	
}
